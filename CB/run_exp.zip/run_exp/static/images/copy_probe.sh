for i in `seq 1 200`
do
  cp stims-12.png probe-${i}.png
done
