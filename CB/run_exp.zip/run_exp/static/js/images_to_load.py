from glob import glob

z = glob("../audio/*")
print(z)
